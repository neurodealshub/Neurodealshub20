Mobile-friendly Cinematic Generator
Drag & drop images or links onto the preview area. Ready for Netlify/GitHub Pages.