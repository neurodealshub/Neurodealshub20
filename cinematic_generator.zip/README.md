# Cinematic Prompt Generator

This is a ready-to-deploy web generator for 1-minute cinematic videos compatible with Google Veo 3.

## Deployment Instructions

1. Upload `index.html` to GitHub repository.
2. Enable GitHub Pages in repository settings.
3. Open your site URL provided by GitHub Pages.
